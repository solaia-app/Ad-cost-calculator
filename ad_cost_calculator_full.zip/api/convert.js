export default async function handler(req,res){
  try{
    const { amount, from, to } = req.query;
    if(!amount||!from||!to) return res.status(400).json({error:'missing params'});
    const url = `https://api.exchangerate.host/convert?from=${from}&to=${to}&amount=${amount}`;
    const r = await fetch(url);
    if(!r.ok) return res.status(502).json({error:'rate provider error'});
    const j = await r.json();
    const rate = j.info && j.info.rate ? j.info.rate : j.result/amount;
    return res.status(200).json({result:j.result, rate});
  }catch(e){console.error(e);return res.status(500).json({error:'internal'});}
}
